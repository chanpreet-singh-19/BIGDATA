package userinterface;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/******
 * <p> Title: mainline.java </p>
 *
 * <p> Description: A JavaFX demonstration application of student administration </p>
 *
 * <p> Copyright: Chanpreet singh� 2019 </p>
 *
 * @author chanoreet singh
 *        
 *
 * @version 4.01 2019-12-0 the application for student administration
 *
 */

public class Mainline extends Application {

public final static double WINDOW_WIDTH = 850;
public final static double WINDOW_HEIGHT = 550;
public final static double WINDOW_WIDTH2 = 980;

/**********
* This is the start method that is called once the application has been loaded into memory and is
* ready to get to work.
*
* In designing this application I have elected to IGNORE all opportunities for automatic layout
* support and instead have elected to manually position each GUI element and its properties in
* order to exercise complete control over the user interface look and feel.
*
*/

@Override
public void start(Stage theStage) throws Exception {
theStage.setTitle("STUDENT REGISTRATION"); // Label the stage (a window)
Pane theRoot = new Pane(); // Create a pane within the window
new UserInterfaceEbook(theRoot);
Scene theScene = new Scene(theRoot, WINDOW_WIDTH2, WINDOW_HEIGHT); // Create the scene
theStage.setScene(theScene); // Set the scene on the stage
theStage.show();
}
public static void main(String[] args) { // This method may not be required
launch(args); // for all JavaFX applications using
} // other IDEs.
}