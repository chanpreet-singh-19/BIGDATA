package userinterface;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;

public class UserInterfaceEbook {

private final double BUTTON_WIDTH = 60;
private final double BUTTON_OFFSET = BUTTON_WIDTH/2;

// These are the application values required by the user interface
private Label label_Double_Mainline = new Label("STUDENT REGISTRATION");
private ComboBox <String> comboBox1 = new ComboBox <String>();

private Label label_Operand1 = new Label("COURSE");
private Label label_Operand2 = new Label("Reg_no");
private Label label_Operand3 = new Label("Roll_no");
private Label label_Operand4 = new Label("Name");
private Label label_Operand5 = new Label("Father_name");
private Label label_Operand6 = new Label("Mother_name");
private Label label_Operand7 = new Label("Semester");
private Label label_Operand8 = new Label("Year");
private TextField text_Operand1 = new TextField();
private TextField text_Operand2 = new TextField();
private TextField text_Operand3 = new TextField();
private TextField text_Operand4 = new TextField();
private TextField text_Operand5 = new TextField();
private TextField text_Operand6 = new TextField();
private TextField text_Operand7 = new TextField();
private Button button_submit = new Button("Submit");
    



private double buttonSpace; // This is the white space between the operator buttons.




/**********************************************************************************************

Constructors

**********************************************************************************************/

/**********
* This method initializes all of the elements of the graphical user interface. These assignments
* determine the location, size, font, color, and change and event handlers for each GUI object.
*/

public UserInterfaceEbook(Pane theRoot) {

// There are five gaps. Compute the button space accordingly.
buttonSpace =  Mainline.WINDOW_WIDTH / 6;

// Label theScene with the name of the  Mainline, centered at the top of the pane
setupLabelUI(label_Double_Mainline, "Arial", 35, Mainline.WINDOW_WIDTH, Pos.CENTER, 0, 5);

// Label the first operand just above it, left aligned
setupLabelUI(label_Operand1, "Arial", 20,  Mainline.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 10, 75);
setupLabelUI(label_Operand2, "Arial", 20,  Mainline.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 10, 120);
setupLabelUI(label_Operand3, "Arial", 20,  Mainline.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 10, 180);
setupLabelUI(label_Operand4, "Arial", 20,  Mainline.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 10, 240);
setupLabelUI(label_Operand5, "Arial", 20,  Mainline.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 10, 300);
setupLabelUI(label_Operand6, "Arial", 20,  Mainline.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 10, 360);
setupLabelUI(label_Operand7, "Arial", 20,  Mainline.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 10, 420);

setupLabelUI(label_Operand8, "Arial", 20,  Mainline.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 10, 480);


setupTextUI(text_Operand1, "Arial", 18, 260, Pos.BASELINE_LEFT, 150, 120, true);

setupTextUI(text_Operand2, "Arial", 18, 260, Pos.BASELINE_LEFT, 150, 180, true);

setupTextUI(text_Operand3, "Arial", 18, 260, Pos.BASELINE_LEFT, 150, 240, true);

setupTextUI(text_Operand4, "Arial", 18, 260, Pos.BASELINE_LEFT, 150, 300, true);
setupTextUI(text_Operand5, "Arial", 18, 260, Pos.BASELINE_LEFT, 150, 360, true);
setupTextUI(text_Operand6, "Arial", 18, 260, Pos.BASELINE_LEFT, 150, 420, true);
setupTextUI(text_Operand7, "Arial", 18, 260, Pos.BASELINE_LEFT, 150, 480, true);

setupButtonUI(button_submit, "Symbol", 22, BUTTON_WIDTH, Pos.BASELINE_LEFT, 3.5 * buttonSpace-BUTTON_OFFSET, 480);
button_submit.setOnAction((event) -> {  });


ComboBox <String> comboBox1 = new ComboBox<String>();
comboBox1.getItems().addAll("MCA ","BCA"," Btech ","NURISNG","MBBS");
comboBox1.setLayoutX(150); comboBox1.setLayoutY(70);



// Place all of the just-initialized GUI elements into the pane
theRoot.getChildren().addAll(label_Double_Mainline,text_Operand1,text_Operand6,text_Operand7,label_Operand8,button_submit,text_Operand2,text_Operand3,text_Operand4,text_Operand5 ,label_Operand5, label_Operand6, label_Operand7, label_Operand4, label_Operand1,label_Operand3, label_Operand2, comboBox1  );

}


private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y){
l.setFont(Font.font(ff, f));
l.setMinWidth(w);
l.setAlignment(p);
l.setLayoutX(x);
l.setLayoutY(y);
}


private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y){
b.setFont(Font.font(ff, f));
b.setMinWidth(w);
b.setAlignment(p);
b.setLayoutX(x);
b.setLayoutY(y);
}
private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e){
	t.setFont(Font.font(ff, f));
	t.setMinWidth(w);
	t.setMaxWidth(w);
	t.setAlignment(p);
	t.setLayoutX(x);
	t.setLayoutY(y);		
	t.setEditable(e);
}



private void setupButton(Button b, int w, int x, int y) {
b.setMinWidth(w);
b.setAlignment(Pos.BASELINE_CENTER);
b.setLayoutX(x);
b.setLayoutY(y);
}




}
